module.exports = {
    //Database connection url
    MongoURI: 'mongodb://localhost:27017/notekeeper'
};
