# NoteKeeper
This simple Web-Application is my HomeWork project for Serverside Javascript course.
It implements all CRUD functions on the notes. The notes are connected to Users, so every User has its
own notes. You can Login, Register, Modify your profile.

## How to use it
